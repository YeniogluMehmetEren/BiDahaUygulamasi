package com.example.emptyviewsactivity.SharedPrefs
/*
data class User(
    var name: String,
    var surname: String,
    var email: String,
    var password: String,
    var isItActive: Boolean
)*/
